import torch
from trainer import Trainer
from dataloader import CreateDataset
import pandas as pd

import wandb
wandb.login(key="b46a760f71842e87d8ac966f77b2db06d0a7085a")

architectures=["cnn"]
model_names=["vinai/phobert-base-v2"]

train_set = pd.read_csv('data/train2.csv')
test_set  = pd.read_csv('data/test2.csv')

for architecture in architectures:
  for i, bert_name in  enumerate(model_names):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print("_____________",bert_name,"______________")
    wandb.init(
      project = "2-Head_Bert",
      name = bert_name + architecture + "_2-head_7_3" + "smart",
    )
    batch_size = 64
    # if "large" in model_name:
    #   batch_size=4

    train_data_loader = CreateDataset(train_set['text'], train_set['label_x'],train_set['label_y'], bert_name, batch_size=batch_size).todataloader()
    test_data_loader  = CreateDataset(test_set['text'], test_set['label_x'],test_set['label_y'], bert_name, batch_size=batch_size).todataloader()
    bertcnn=Trainer(bert_name,  train_data_loader, test_data_loader, model=architecture)
    bertcnn.fit(schedule=True,epochs=60,report=True,name="smart-v1.0")
    wandb.finish()

    del bertcnn
    del train_data_loader
    del test_data_loader
    torch.cuda.empty_cache()

    print("________________End___________________")